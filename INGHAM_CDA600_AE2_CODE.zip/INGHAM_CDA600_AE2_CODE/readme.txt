Notes:
In order to run the Arduino code, the ip of the arduino and server must be changed to match your config, or configured to use DHCP
It's best to view it in the Arduino IDE for syntax highlighting

The php files are from the htdocs folder in xampp, which is running an apache server and MySQL
In order to access the admin page, you must use login.html with the password admin1